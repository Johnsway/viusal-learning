#include <opencv2/opencv.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <iostream>
#include <filesystem>

namespace fs = std::filesystem;

void matchFeatures(const cv::Mat& img1, const cv::Mat& img2) {
    // 创建SIFT特征检测器
    cv::Ptr<cv::Feature2D> detector = cv::xfeatures2d::SIFT::create();
    
    // 检测特征点并计算描述符
    std::vector<cv::KeyPoint> keypoints1, keypoints2;
    cv::Mat descriptors1, descriptors2;
    detector->detectAndCompute(img1, cv::noArray(), keypoints1, descriptors1);
    detector->detectAndCompute(img2, cv::noArray(), keypoints2, descriptors2);

    // 创建BFMatcher进行特征匹配
    cv::BFMatcher matcher(cv::NORM_L2);
    std::vector<cv::DMatch> matches;
    matcher.match(descriptors1, descriptors2, matches);

    // 绘制匹配结果
    cv::Mat img_matches;
    cv::drawMatches(img1, keypoints1, img2, keypoints2, matches, img_matches);

    // 显示匹配结果
    cv::imshow("Matches", img_matches);
    cv::waitKey(0);
}

int main(int argc, char** argv) {
    // 读取模板图像
    std::string templates_dir = "templates";
    std::string archive_dir = "archive";

    for (const auto& template_entry : fs::directory_iterator(templates_dir)) {
        cv::Mat template_img = cv::imread(template_entry.path().string(), cv::IMREAD_GRAYSCALE);

        for (const auto& archive_entry : fs::directory_iterator(archive_dir)) {
            cv::Mat archive_img = cv::imread(archive_entry.path().string(), cv::IMREAD_GRAYSCALE);

            // 检查图像是否成功加载
            if (template_img.empty() || archive_img.empty()) {
                std::cerr << "Could not open or find the images!" << std::endl;
                continue;
            }

            // 进行特征匹配
            matchFeatures(template_img, archive_img);
        }
    }

    return 0;
}

