#include <opencv2/opencv.hpp>
#include <fstream>
#include <opencv2/opencv.hpp>
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>

void transformImage(const std::string& img_name, double img_scale, int interpolation, int img_Horizontal, int img_Vertical, const std::string& rotation_center, double rotation_angle) {
    std::cout << "Processing image: " << img_name << std::endl;

    cv::Mat img = cv::imread(img_name);
    if (img.empty()) {
        std::cerr << "Could not open or find the image: " << img_name << std::endl;
        return;
    }

    // Scale image
    cv::Mat scaled_img;
    cv::resize(img, scaled_img, cv::Size(), img_scale, img_scale, interpolation);

    // Create a white background
    cv::Mat white_background = cv::Mat::zeros(scaled_img.size(), scaled_img.type());
    white_background.setTo(cv::Scalar(255, 255, 255));
    scaled_img.copyTo(white_background(cv::Rect(0, 0, scaled_img.cols, scaled_img.rows)));

    // Translate image
    cv::Mat translation_mat = (cv::Mat_<double>(2, 3) << 1, 0, img_Horizontal, 0, 1, img_Vertical);
    cv::warpAffine(white_background, white_background, translation_mat, white_background.size(), cv::INTER_LINEAR, cv::BORDER_CONSTANT, cv::Scalar(255, 255, 255));

    // Rotate image
    cv::Point2f center(white_background.cols / 2.0, white_background.rows / 2.0);
    if (rotation_center == "center") {
        center = cv::Point2f(white_background.cols / 2.0, white_background.rows / 2.0);
    }
    cv::Mat rotation_mat = cv::getRotationMatrix2D(center, rotation_angle, 1.0);
    cv::warpAffine(white_background, white_background, rotation_mat, white_background.size(), cv::INTER_LINEAR, cv::BORDER_CONSTANT, cv::Scalar(255, 255, 255));

    // Ensure the output file name is valid
    std::string output_name = "transformed_" + img_name.substr(img_name.find_last_of("/\\") + 1);
    if (cv::imwrite(output_name, white_background)) {
        std::cout << "Image saved successfully: " << output_name << std::endl;
    } else {
        std::cerr << "Failed to save the image: " << output_name << std::endl;
    }
}

double parseScaleOrSize(const std::string& size_or_scale_str, int img_width, int img_height) {
    std::string cleaned = size_or_scale_str;
    cleaned.erase(std::remove(cleaned.begin(), cleaned.end(), '"'), cleaned.end());
    cleaned.erase(std::remove(cleaned.begin(), cleaned.end(), ' '), cleaned.end());

    if (cleaned.find(',') != std::string::npos) {
        // It's a size, parse width and height
        size_t comma_pos = cleaned.find(',');
        int width = std::stoi(cleaned.substr(0, comma_pos));
        int height = std::stoi(cleaned.substr(comma_pos + 1));
        return std::min(static_cast<double>(width) / img_width, static_cast<double>(height) / img_height);
    } else {
        // It's a scale
        return std::stod(cleaned);
    }
}

int main(int argc, char** argv) {
    std::ifstream file("/home/johnsway/ImageTransform/experiment1.csv");
    if (!file.is_open()) {
        std::cerr << "Failed to open the CSV file." << std::endl;
        return -1;
    }

    std::string line, word;
    std::getline(file, line); // Skip the header

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::vector<std::string> row;

        // Parse the line considering quoted values
        bool inside_quotes = false;
        std::string current_word;
        for (char c : line) {
            if (c == '"' && (current_word.empty() || current_word.back() != '\\')) {
                inside_quotes = !inside_quotes;
                current_word += c;
            } else if (c == ',' && !inside_quotes) {
                row.push_back(current_word);
                current_word.clear();
            } else {
                current_word += c;
            }
        }
        if (!current_word.empty()) {
            row.push_back(current_word);
        }

        try {
            std::string img_name = row[0];

            cv::Mat img = cv::imread(img_name);
            if (img.empty()) {
                std::cerr << "Could not open or find the image: " << img_name << std::endl;
                continue;
            }

            double img_scale = parseScaleOrSize(row[1], img.cols, img.rows);
            int interpolation = (row[2] == "NEAREST") ? cv::INTER_NEAREST : cv::INTER_LINEAR;
            int img_Horizontal = std::stoi(row[3]);
            int img_Vertical = std::stoi(row[4]);
            std::string rotation_center = row[5];
            double rotation_angle = std::stod(row[6]);

            transformImage(img_name, img_scale, interpolation, img_Horizontal, img_Vertical, rotation_center, rotation_angle);
        } catch (const std::invalid_argument& e) {
            std::cerr << "Invalid argument: " << e.what() << " in line: " << line << std::endl;
        } catch (const std::out_of_range& e) {
            std::cerr << "Out of range error: " << e.what() << " in line: " << line << std::endl;
        } catch (const std::exception& e) {
            std::cerr << "Exception: " << e.what() << " in line: " << line << std::endl;
        }
    }

    return 0;
}

