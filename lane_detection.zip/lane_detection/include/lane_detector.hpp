#ifndef LANE_DETECTOR_HPP
#define LANE_DETECTOR_HPP

#include <opencv2/opencv.hpp>

class LaneDetector {
public:
    cv::Mat detectLanes(const cv::Mat &inputImage);
};

#endif

