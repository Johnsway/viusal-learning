#include <opencv2/opencv.hpp>
#include "lane_detector.hpp"

int main() {
    cv::Mat image = cv::imread("../data/input_image.jpg");
    if (image.empty()) {
        std::cerr << "Could not read the image" << std::endl;
        return 1;
    }

    LaneDetector detector;
    cv::Mat output = detector.detectLanes(image);

    cv::imshow("Detected Lanes", output);
    cv::waitKey(0);

    return 0;
}

