#include "lane_detector.hpp"

cv::Mat LaneDetector::detectLanes(const cv::Mat &inputImage) {
    // Load mask image
    cv::Mat mask = cv::imread("../data/car_mask.png", cv::IMREAD_GRAYSCALE);
    if (mask.empty()) {
        std::cerr << "Could not read the mask image" << std::endl;
        return inputImage;
    }
    
    // Ensure mask is the same size as input image
    if (mask.size() != inputImage.size()) {
        cv::resize(mask, mask, inputImage.size());
    }

    // Invert the mask
    cv::bitwise_not(mask, mask);

    // Display the mask to ensure it's correctly loaded
    cv::imshow("Mask", mask);

    // Apply mask to input image
    cv::Mat maskedInput;
    cv::bitwise_and(inputImage, inputImage, maskedInput, mask);

    // Display the masked input image
    cv::imshow("Masked Input", maskedInput);

    // Convert to grayscale
    cv::Mat gray;
    cv::cvtColor(maskedInput, gray, cv::COLOR_BGR2GRAY);

    // Display the grayscale image
    cv::imshow("Grayscale Image", gray);

    // Apply Gaussian blur
    cv::GaussianBlur(gray, gray, cv::Size(5, 5), 1.5);
    
    // Apply Canny edge detector
    cv::Mat edges;
    cv::Canny(gray, edges, 50, 150);

    // Display the edges image
    cv::imshow("Edges", edges);

    // Detect lines using Hough transform
    std::vector<cv::Vec4i> line_segments;
    cv::HoughLinesP(edges, line_segments, 1, CV_PI/180, 50, 50, 10);

    // Draw lines on the original input image
    cv::Mat output = inputImage.clone();
    for (size_t i = 0; i < line_segments.size(); i++) {
        cv::Vec4i l = line_segments[i];
        cv::line(output, cv::Point(l[0], l[1]), cv::Point(l[2], l[3]), cv::Scalar(0, 0, 255), 3, cv::LINE_AA);
    }

    return output;
}

